# SpaceMax V0.2

Native Android media optimizer designed for Samsung foldables.

## Included

- MediaStore video, photo, and audio scanner ordered by file size
- All/Videos/Photos/Audio filters
- Estimated recoverable storage
- Foldable two-pane layout at 600dp and above
- HEVC/H.265 video optimization using AndroidX Media3 Transformer
- Safe-copy workflow: originals are never deleted
- Optimized media appears in Samsung Gallery under `Movies/SpaceMax`
- Dark interface and cover-screen layout

## Build

Open the `SpaceMax` folder in Android Studio, allow Gradle sync, then run on an Android 10+ device. On Android 13+, grant video access when prompted.

## Safety

V0.2 does not replace or delete originals. Review the optimized copy in Gallery first. Photo/audio re-encoding, duplicate detection, WorkManager scheduling, charging/thermal checks, and automatic rules remain disabled until their verification paths are complete.
