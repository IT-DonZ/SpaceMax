package com.gary.spacemax

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpaceMaxApp() }
    }
}

private val Ink = Color(0xFF080C11)
private val Panel = Color(0xFF111820)
private val Green = Color(0xFF2BE0A7)

@Composable
fun SpaceMaxApp(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val permissions = if (Build.VERSION.SDK_INT >= 33) arrayOf(
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_AUDIO,
    ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { vm.scan() }
    LaunchedEffect(Unit) { launcher.launch(permissions) }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Ink, surface = Panel)) {
        Surface(Modifier.fillMaxSize()) {
            val wide = LocalConfiguration.current.screenWidthDp >= 600
            if (wide) Row(Modifier.fillMaxSize()) {
                Dashboard(state, { vm.scan() }, Modifier.weight(.42f))
                MediaBrowser(state, vm::select, vm::filter, vm::optimizeSelected, Modifier.weight(.58f))
            } else Column(Modifier.fillMaxSize()) {
                Dashboard(state, { vm.scan() }, Modifier.fillMaxWidth())
                MediaBrowser(state, vm::select, vm::filter, vm::optimizeSelected, Modifier.fillMaxWidth().weight(1f))
            }
        }
    }
}

@Composable
private fun Dashboard(state: SpaceMaxState, scan: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Storage, null, tint = Green, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(10.dp))
            Text("SpaceMax", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
        Text("Your media. Smaller. Still yours.", color = Color(0xFFA9B6C3))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("SPACE RECOVERY", color = Green, style = MaterialTheme.typography.labelMedium)
                Text(formatBytes(state.recoverableBytes), style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
                Text("estimated from ${state.media.size} media files • ${formatBytes(state.totalBytes)} scanned", color = Color(0xFFA9B6C3))
                if (state.historyCount > 0) Text("${state.historyCount} safe optimizations completed", color = Color(0xFFA9B6C3), style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(progress = { if (state.totalBytes == 0L) 0f else (state.recoverableBytes.toFloat() / state.totalBytes).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
            }
        }
        Button(onClick = scan, enabled = !state.loading, modifier = Modifier.fillMaxWidth().height(56.dp)) {
            Icon(Icons.Default.Bolt, null); Spacer(Modifier.width(8.dp)); Text(if (state.loading) "Scanning…" else "Scan Again")
        }
        state.message?.let { Text(it, color = if (state.optimizing) Green else Color(0xFFCFD8E3)) }
        Text("V0.2 keeps every original. Optimized copies are saved separately until you review them.", color = Color(0xFF82909E), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun MediaBrowser(state: SpaceMaxState, select: (MediaItem) -> Unit, filter: (MediaKind?) -> Unit, optimize: () -> Unit, modifier: Modifier = Modifier) {
    Column(modifier.padding(20.dp)) {
        Text("Largest media", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(selected = state.filter == null, onClick = { filter(null) }, label = { Text("All") })
            FilterChip(selected = state.filter == MediaKind.VIDEO, onClick = { filter(MediaKind.VIDEO) }, label = { Text("Videos") })
            FilterChip(selected = state.filter == MediaKind.PHOTO, onClick = { filter(MediaKind.PHOTO) }, label = { Text("Photos") })
            FilterChip(selected = state.filter == MediaKind.AUDIO, onClick = { filter(MediaKind.AUDIO) }, label = { Text("Audio") })
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(state.visibleMedia.take(200), key = { "${it.kind}-${it.id}" }) { item ->
                val active = state.selected?.id == item.id && state.selected?.kind == item.kind
                Card(Modifier.fillMaxWidth().clickable { select(item) }, colors = CardDefaults.cardColors(containerColor = if (active) Color(0xFF173C36) else Panel)) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, maxLines = 1, fontWeight = FontWeight.Medium)
                            val details = if (item.kind == MediaKind.AUDIO) formatDuration(item.durationMs) else "${item.width}×${item.height}"
                            Text("$details • ${formatBytes(item.sizeBytes)}", color = Color(0xFFA9B6C3), style = MaterialTheme.typography.bodySmall)
                        }
                        Text("−${formatBytes(item.estimatedSaving)}", color = Green)
                    }
                }
            }
        }
        if (state.selected != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = optimize, enabled = !state.optimizing, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text(if (state.optimizing) "Optimizing…" else if (state.selected.kind == MediaKind.VIDEO) "Optimize selected video" else "Preview estimated savings")
            }
        }
    }
}

private fun formatDuration(milliseconds: Long): String {
    val totalSeconds = milliseconds / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

private fun formatBytes(bytes: Long): String {
    val gb = bytes / 1_073_741_824.0
    val mb = bytes / 1_048_576.0
    return if (gb >= 1) "%.1f GB".format(gb) else "%.0f MB".format(mb)
}
