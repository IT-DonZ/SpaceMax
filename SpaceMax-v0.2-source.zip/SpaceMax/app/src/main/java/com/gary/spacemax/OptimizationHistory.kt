package com.gary.spacemax

import android.content.Context
import android.net.Uri

/** Lightweight local audit trail; no filenames or history leave the device. */
class OptimizationHistory(context: Context) {
    private val preferences = context.getSharedPreferences("optimization_history", Context.MODE_PRIVATE)

    fun record(original: MediaItem, output: Uri) {
        val entries = preferences.getStringSet("entries", emptySet()).orEmpty().toMutableSet()
        entries += listOf(
            System.currentTimeMillis().toString(),
            original.id.toString(),
            original.sizeBytes.toString(),
            output.toString(),
        ).joinToString("|")
        preferences.edit().putStringSet("entries", entries.toList().takeLast(100).toSet()).apply()
    }

    fun count(): Int = preferences.getStringSet("entries", emptySet()).orEmpty().size
}
