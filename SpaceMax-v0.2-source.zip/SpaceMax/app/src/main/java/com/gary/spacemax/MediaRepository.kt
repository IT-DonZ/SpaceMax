package com.gary.spacemax

import android.content.ContentUris
import android.content.Context
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaRepository(private val context: Context) {
    suspend fun allMedia(): List<MediaItem> = withContext(Dispatchers.IO) {
        (videos() + photos() + audio()).sortedByDescending { it.sizeBytes }
    }

    private fun videos(): List<MediaItem> {
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE,
        )
        return context.contentResolver.query(
            collection, projection, null, null,
            "${MediaStore.Video.Media.SIZE} DESC"
        )?.use { cursor ->
            val id = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val name = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val size = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            val duration = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val width = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
            val height = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
            val mime = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
            buildList {
                while (cursor.moveToNext()) add(
                    MediaItem(
                        id = cursor.getLong(id),
                        uri = ContentUris.withAppendedId(collection, cursor.getLong(id)),
                        name = cursor.getString(name) ?: "Video",
                        sizeBytes = cursor.getLong(size),
                        durationMs = cursor.getLong(duration),
                        width = cursor.getInt(width),
                        height = cursor.getInt(height),
                        mimeType = cursor.getString(mime) ?: "video/*",
                        kind = MediaKind.VIDEO,
                    )
                )
            }
        } ?: emptyList()
    }

    private fun photos(): List<MediaItem> {
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE, MediaStore.Images.Media.WIDTH,
            MediaStore.Images.Media.HEIGHT, MediaStore.Images.Media.MIME_TYPE,
        )
        return context.contentResolver.query(collection, projection, null, null, "${MediaStore.Images.Media.SIZE} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            val size = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
            val width = c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH)
            val height = c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT)
            val mime = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
            buildList {
                while (c.moveToNext()) add(MediaItem(c.getLong(id), ContentUris.withAppendedId(collection, c.getLong(id)), c.getString(name) ?: "Photo", c.getLong(size), 0, c.getInt(width), c.getInt(height), c.getString(mime) ?: "image/*", MediaKind.PHOTO))
            }
        } ?: emptyList()
    }

    private fun audio(): List<MediaItem> {
        val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        val projection = arrayOf(
            MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE, MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
        )
        return context.contentResolver.query(collection, projection, null, null, "${MediaStore.Audio.Media.SIZE} DESC")?.use { c ->
            val id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val name = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
            val size = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
            val duration = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val mime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
            buildList {
                while (c.moveToNext()) add(MediaItem(c.getLong(id), ContentUris.withAppendedId(collection, c.getLong(id)), c.getString(name) ?: "Audio", c.getLong(size), c.getLong(duration), 0, 0, c.getString(mime) ?: "audio/*", MediaKind.AUDIO))
            }
        } ?: emptyList()
    }
}
