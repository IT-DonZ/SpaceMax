package com.gary.spacemax

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import androidx.media3.common.MediaItem as Media3Item
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

class VideoOptimizer(private val context: Context) {
    fun optimize(item: MediaItem, listener: Listener) {
        val temp = File(context.cacheDir, "spacemax_${item.id}_${System.currentTimeMillis()}.mp4")

        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H265)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, result: ExportResult) {
                    runCatching { publish(temp, item) }
                        .onSuccess(listener::onComplete)
                        .onFailure { listener.onError(it.localizedMessage ?: "Could not save optimized video") }
                    temp.delete()
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    result: ExportResult,
                    exception: ExportException,
                ) {
                    temp.delete()
                    listener.onError(exception.localizedMessage ?: "Optimization failed")
                }
            }).build()

        val edited = EditedMediaItem.Builder(Media3Item.fromUri(item.uri)).build()
        transformer.start(edited, temp.absolutePath)
    }

    private fun publish(temp: File, item: MediaItem): android.net.Uri {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "SpaceMax_${item.name.substringBeforeLast('.')}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SpaceMax")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val output = requireNotNull(
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ) { "Could not create the Gallery entry" }
        try {
            context.contentResolver.openOutputStream(output, "w")!!.use { target ->
                temp.inputStream().use { source -> source.copyTo(target) }
            }
            context.contentResolver.update(output, ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }, null, null)
            return output
        } catch (error: Throwable) {
            context.contentResolver.delete(output, null, null)
            throw error
        }
    }

    interface Listener {
        fun onComplete(uri: android.net.Uri)
        fun onError(message: String)
    }
}
