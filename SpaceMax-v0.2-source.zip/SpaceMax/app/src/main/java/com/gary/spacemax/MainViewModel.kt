package com.gary.spacemax

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class SpaceMaxState(
    val loading: Boolean = false,
    val media: List<MediaItem> = emptyList(),
    val filter: MediaKind? = null,
    val selected: MediaItem? = null,
    val optimizing: Boolean = false,
    val message: String? = null,
    val historyCount: Int = 0,
) {
    val visibleMedia get() = media.filter { filter == null || it.kind == filter }
    val totalBytes get() = media.sumOf { it.sizeBytes }
    val recoverableBytes get() = media.sumOf { it.estimatedSaving }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = MediaRepository(application)
    private val optimizer = VideoOptimizer(application)
    private val history = OptimizationHistory(application)
    private val _state = MutableStateFlow(SpaceMaxState(historyCount = history.count()))
    val state = _state.asStateFlow()

    fun scan(clearMessage: Boolean = true) = viewModelScope.launch {
        _state.value = _state.value.copy(loading = true, message = if (clearMessage) null else _state.value.message)
        runCatching { repo.allMedia() }
            .onSuccess { items -> _state.value = _state.value.copy(loading = false, media = items, selected = items.firstOrNull()) }
            .onFailure { _state.value = _state.value.copy(loading = false, message = it.localizedMessage) }
    }

    fun select(item: MediaItem) { _state.value = _state.value.copy(selected = item) }
    fun filter(kind: MediaKind?) {
        val visible = _state.value.media.filter { kind == null || it.kind == kind }
        _state.value = _state.value.copy(filter = kind, selected = visible.firstOrNull())
    }

    fun optimizeSelected() {
        val item = _state.value.selected ?: return
        if (item.kind != MediaKind.VIDEO) {
            _state.value = _state.value.copy(message = "Photo and audio optimization are queued for V0.3. V0.2 analyzes them safely.")
            return
        }
        _state.value = _state.value.copy(optimizing = true, message = "Optimizing ${item.name}…")
        optimizer.optimize(item, object : VideoOptimizer.Listener {
            override fun onComplete(uri: Uri) {
                history.record(item, uri)
                _state.value = _state.value.copy(optimizing = false, historyCount = history.count(), message = "Optimized copy saved in Movies/SpaceMax. Original kept safely.")
                scan(clearMessage = false)
            }
            override fun onError(message: String) {
                _state.value = _state.value.copy(optimizing = false, message = message)
            }
        })
    }
}
