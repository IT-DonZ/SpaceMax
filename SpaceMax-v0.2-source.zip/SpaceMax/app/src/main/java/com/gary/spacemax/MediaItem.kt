package com.gary.spacemax

import android.net.Uri

enum class MediaKind { VIDEO, PHOTO, AUDIO }

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val mimeType: String,
    val kind: MediaKind,
) {
    val estimatedSaving: Long get() = (sizeBytes * savingRatio()).toLong()

    private fun savingRatio(): Double = when {
        kind == MediaKind.AUDIO -> .25
        kind == MediaKind.PHOTO && mimeType.contains("heif", true) -> .08
        kind == MediaKind.PHOTO -> .30
        mimeType.contains("hevc", true) || mimeType.contains("h265", true) -> .12
        width >= 3840 -> .58
        width >= 1920 -> .44
        else -> .28
    }
}
